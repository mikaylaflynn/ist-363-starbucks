<?php 
get_header(); 
include 'partials/posts/listByCategory.php';
//include 'partials/posts/list.php';
//include 'partials/products/list.php';
//include 'partials/locations/list.php'; 
//include 'partials/employees/list.php';
get_footer(); 
?>
