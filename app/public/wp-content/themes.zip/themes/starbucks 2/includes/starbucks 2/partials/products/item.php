<article>
	<?php the_post_thumbnail('thumbnail'); ?>
	<h3><?php the_title(); ?></h3>
</article>
