<?php
/* Template name: Menu */
?>

<?php get_header(); ?>

<main>
	<h1>MENUUUUUUUUUU!</h1>
	<?php include 'partials/products/listByCategory.php'; ?>
</main>

<?php get_footer(); ?>
