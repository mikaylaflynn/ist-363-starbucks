<article class="card">
	<?php the_post_thumbnail('medium', array(
		'class' => 'card-img'
	)); ?>
	<h3 class="card-title"><?php the_title(); ?></h3>
</article>
