	</main>
	<footer>
		Copyright 2022 Starbucks Coffee Company.
	</footer>
</body>
</html>
