	</main>
	<footer>
		Copyright 2022 Starbucks Coffee Company.
	</footer>
	<script src="<?php bloginfo('template_directory'); ?>/js/main.js"></script>
</body>
</html>
