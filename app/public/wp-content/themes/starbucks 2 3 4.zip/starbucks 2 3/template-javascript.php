<?php
/*Template name: Basic JavaScript */
?>
<?php get_header(); ?>
<h1>Basic JavaScipt template</h1>

<div id="showcase"></div>
<div id="buttonsContainer">
    <button id="redBtn">Red</button>
    <button id ="orangeBtn">Orange</button>
    <button id="yellowBtn">Yellow</button>
</div><!-- /#buttonsContainer -->

<script src="<?php bloginfo('template_directory'); ?>/js/basic-javascript.js"></script>