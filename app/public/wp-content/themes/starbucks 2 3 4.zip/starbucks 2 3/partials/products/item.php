<article class="item">
	<?php the_post_thumbnail('thumbnail', array (
		'class' => 'responsive-img'
	)); ?>
	<h3><?php the_title(); ?></h3>
</article>