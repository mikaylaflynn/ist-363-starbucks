<div class="showcase">
    <img 
        src="<?php bloginfo('template_directory'); ?>/img/showcase.jpeg" 
        alt="Two coffee mugs" 
        class="responsive-img"
    >

   <div class="showcase-text">
       <h1>Menu</h1>
       <p>Check out the Starbucks menu and get nutritional information about each menu item.</p>     
   </div><!-- /. showcase text -->
</div><!-- /. showcase -->