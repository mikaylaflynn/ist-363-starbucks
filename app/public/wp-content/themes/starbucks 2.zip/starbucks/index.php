<?php get_header(); ?>

<main>
    <h2>Posts</h2>
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <article>
            <?php the_post_thumbnail('thumbnail'); ?>
            <h3><?php the_title(); ?></h3>
            <h4>Written by <?php the_author();?> </h4>
            <?php the_excerpt(); ?>
            <p><a href="<?php the_permalink(); ?>">Read More</a></p>
        </article>
    <?php endwhile; else : ?>
        <p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
    <?php endif; ?>
</main>

<?php get_footer(); ?>
