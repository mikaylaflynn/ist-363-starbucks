<?php
require get_template_directory() . '/includes/add-theme-support.php';
require get_template_directory() . '/includes/register-post-types.php';
require get_template_directory() . '/includes/register-taxonomies.php';
