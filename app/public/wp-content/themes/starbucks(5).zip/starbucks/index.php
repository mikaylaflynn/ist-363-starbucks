<?php 
get_header(); 
include 'partials/locations/list.php'; 
include 'partials/employees/list.php'; 
get_footer(); 
?>
