<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/style.css">
</head>
<body>
	<header>
		<h1>Starbucks</h1>
	</header>
	<nav>
		<ul>
			<li>
				<a href="/">Home</a>
			</li>
			<li>
				<a href="/menu">Menu</a>
			</li>
			<li>
				<a href="/locations">Locations</a>
			</li>
			<li>
				<a href="/employees">Employees</a>
			</li>
		</ul>
	</nav>
	<main>
