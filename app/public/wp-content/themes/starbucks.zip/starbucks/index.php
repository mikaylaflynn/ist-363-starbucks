<?php get_header(); ?>
<main>
    <h2>Posts</h2>
</main>
<?php get_footer(); ?>
