const colors = [
    {
        name: "Crystal Black Silica",
        slug: "crystal-black-silica",
        hex: "#0d0d0b"
    },
    {
        name: "Crimson Red Pearl",
        slug: "crimson-red-pearl",
        hex: "#710e18"
    },
    {
        name: "Sapphire Blue Pearl",
        slug: "sapphire-blue-pearl",
        hex: "#00306d"
    },
    {
        name: "Ice Silver Metallic",
        slug: "ice-silver-metallic",
        hex: "#dfdfdf"
    },
    {
        name: "Lithium Red Pearl",
        slug: "lithium-red-pearl",
        hex: "#b81b18"
    },
    {
        name: "Magnetite Gray Metallic",
        slug: "magnetite-gray-metallic",
        hex: "#5B5E5E"
    },
    {
        name: "Crystal White Pearl",
        slug: "crystal-white-pearl",
        hex: "#eeeeee"
    },
    {
        name: "Ocean Blue Pearl",
        slug: "ocean-blue-pearl",
        hex: "#245f9e"
    },
];

crimson-red-pearl.addEventListener("click", function() {
    //console.log("Clicked");
    showcase.style.backgroundImage = '../impreza/crimson-red-pearl.webp';
    colorHeadline.innerText = 'Crimson Red';
});
crystal-black-silica.addEventListener("click", function() {
    //console.log("Clicked");
    showcase.style.backgroundImage = '../impreza/crystal-black-silica.webp';
    colorHeadline.innerText = 'Crystal Black';
});
crystal-white-pearl.addEventListener("click", function() {
    //console.log("Clicked");
    showcase.style.backgroundImage = '../impreza/crystal-white-pearl.webp';
    colorHeadline.innerText = 'Crimson Red';
});
ice-silver-metallic.addEventListener("click", function() {
    //console.log("Clicked");
    showcase.style.backgroundImage = '../impreza/ice-silver-metallic.webp';
    colorHeadline.innerText = 'Crimson Red';
});
lithium-red-pearl.addEventListener("click", function() {
    //console.log("Clicked");
    showcase.style.backgroundImage = '../impreza/lithium-red-pearl.webp';
    colorHeadline.innerText = 'Crimson Red';
});
magnetite-gray.addEventListener("click", function() {
    //console.log("Clicked");
    showcase.style.backgroundImage = '../impreza/magnetite-gray.webp';
    colorHeadline.innerText = 'Crimson Red';
});
ocean-blue-pearl.addEventListener("click", function() {
    //console.log("Clicked");
    showcase.style.backgroundImage = '../impreza/ocean-blue-pearl.webp';
    colorHeadline.innerText = 'Crimson Red';
});
sapphire-blue-pearl.addEventListener("click", function() {
    //console.log("Clicked");
    showcase.style.backgroundImage = '../impreza/sapphire-blue-pearl.webp';
    colorHeadline.innerText = 'Crimson Red';
});





