<?php
/* Template Name: Subaru Template */
?>
<?php get_header(); ?>
<h1>Subaru Colors</h1>

<div id="showcase"></div>
<div id="buttonsContainer">
    <button id="crimson-red-pearl">Crimson Red</button>
    <button id ="crystal-black-silica">Crystal Black</button>
    <button id="crystal-white-pearl">Crystal White</button>
    <button id="ice-silver-metallic">Ice Silver</button>
    <button id="lithium-red-pearl">Lithium Red</button>
    <button id="magnetite-gray-metallic">Magnetite Gray</button>
    <button id="ocean-blue-pearl">Ocean Blue</button>
    <button id="sapphire-blue-pearl">Sapphire Blue</button>
</div><!-- /#buttonsContainer -->

<script src="<?php bloginfo('template_directory'); ?>/js/subaru.js"></script>