<article>
	<?php the_post_thumbnail('thumbnail'); ?>
	<h3><?php the_field('first_name'); ?> <?php the_field('last_name'); ?></h3>
	<h4><?php the_field('job_title'); ?></h4>
</article>
