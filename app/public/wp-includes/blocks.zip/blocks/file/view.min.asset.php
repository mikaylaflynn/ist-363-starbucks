<?php return array('dependencies' => array(), 'version' => '2a20786ca914ea00891f');
