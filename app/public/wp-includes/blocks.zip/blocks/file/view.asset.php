<?php return array('dependencies' => array(), 'version' => '30e42a0eeaa76bba673e');
