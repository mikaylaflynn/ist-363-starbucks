<?php return array('dependencies' => array(), 'version' => '45f05135277abf0b0408');
