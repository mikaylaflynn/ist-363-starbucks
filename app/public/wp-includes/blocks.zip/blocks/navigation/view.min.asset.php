<?php return array('dependencies' => array(), 'version' => 'c24330f635f5cb9d5e0e');
