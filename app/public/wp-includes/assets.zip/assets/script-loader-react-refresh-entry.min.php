<?php return array('dependencies' => array('wp-react-refresh-runtime'), 'version' => '794dd7047e2302828128');
